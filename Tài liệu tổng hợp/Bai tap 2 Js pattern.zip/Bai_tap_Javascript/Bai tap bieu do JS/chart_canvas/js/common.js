$(document).ready(function(e) 
{
	/*************************************************************************************/
	var canvas = new fabric.Canvas('main_canvas');	
	fabric.Object.prototype.originX = fabric.Object.prototype.originY = 'center';
	canvas.backgroundColor = '#ffffcc';
	
	var index_tab = 0;//index tab
	/*************************************************************************************/
	Array.prototype.max = function() {
	  return Math.max.apply(null, this);
	};
	
	Array.prototype.min = function() {
	  return Math.min.apply(null, this);
	};
	/*************************************************************************************/
	function makeLine(coords) 
	{
		return new fabric.Line(coords, 
		{
		  fill: 'gray',
		  stroke: 'gray',
		  strokeWidth: 1,
		  selectable: false
		});
	}
	
	function makeGrayLine(coords) 
	{
		return new fabric.Line(coords, 
		{
		  fill: 'gray',
		  stroke: 'gray',
		  strokeWidth: 1,
		  selectable: false
		});
	}
	
	function makeGrayLineStrong(coords) 
	{
		return new fabric.Line(coords, 
		{
		  fill: 'gray',
		  stroke: 'gray',
		  strokeWidth: 2,
		  selectable: false
		});
	}
	
	function makeRedLine(coords) 
	{
		return new fabric.Line(coords, 
		{
		  fill: 'red',
		  stroke: 'red',
		  strokeWidth: 2,
		  selectable: false
		});
	}

	function makeBlueLine(coords) 
	{
		return new fabric.Line(coords, 
		{
		  fill: 'blue',
		  stroke: 'blue',
		  strokeWidth: 2,
		  selectable: false
		});
	}
	function makeText(text,left,top)
	{
		return new fabric.Text(text, {
		  fontSize: 12,
		  left:left,
		  top:top,
		  fill:'black',
		  originX: 'center',
		  originY: 'center',
		  selectable: false
		});
	}
	function makeTitle(text,left,top)
	{
		return new fabric.Text(text, {
		  fontSize: 12,
		  left:left,
		  top:top,
		  fill:'black',
		  originX: 'right',
		  originY: 'center',
		  selectable: false
		});
	}
	
	function makeRedText(text,left,top)
	{
		return new fabric.Text(text, {
		  fontSize: 12,
		  left:left,
		  top:top,
		  fill:'red',
		  originX: 'right',
		  originY: 'center',
		  selectable: false
		});
	}
	
	function makeBlueText(text,left,top)
	{
		return new fabric.Text(text, {
		  fontSize: 12,
		  left:left,
		  top:top,
		  fill:'blue',
		  originX: 'right',
		  originY: 'center',
		  selectable: false
		});
	}
	
	function makeCircle(left, top) 
	{
		return new fabric.Circle
		({
			  left: left+0.5,
			  top: top,
			  strokeWidth: 0.5,
			  radius: 1,
			  fill: 'black',
			  stroke: 'black',
			  selectable: false
		});
	}
	function makeTriangle(left,top,angle)
	{
		return new fabric.Triangle
		({  
			width: 4, 
			height: 4, 
			fill: 'black', 
			left: left+0.5, 
			top: top, 
			angle: angle, 
			selectable: false  
		});
	}
	//draw chart
	
	text_value = makeTitle('温度・湿度２４時間データ',550,30);
	canvas.add(text_value);
	drawingFramesChart(array_hour_c,array_hour_percent);
	function drawingFramesChart(array_c,array_percent)//Ox : 720px, Oy 420px
	{
		var main_layer = new fabric.Group([], {	  left: 170,	  top: 50	, selectable: false});
		//draw y (temperature C)
		frameLength_y_c = 80;
		line = makeLine([ 0, 20, 0, 420 ]);
		text_value = makeRedText('温度\n ºC',-5,-10);
		main_layer.add(line,text_value);
		var	temp_c = 40;
		for(i=0;i<=5;i++)
		{
			if(i==0)
			{
				gray_line = makeGrayLineStrong([720,frameLength_y_c*i+20,-100,frameLength_y_c*i+20]);
			}
			else
			{
				gray_line = makeGrayLine([720,frameLength_y_c*i+20,-100,frameLength_y_c*i+20]);	
			}
			text_value = makeRedText(temp_c.toString(),-10,frameLength_y_c*i+13);
			temp_c-=10;
			main_layer.add(text_value,gray_line);
		}
		//draw y (temperature %)
		frameLength_y_temperature = 80;
		//line = makeLine([ -50, 20, -50, 420 ]);
		text_value = makeBlueText('湿度\n %',-50,-10);
		main_layer.add(text_value);
		for(i=0;i<=5;i++)
		{
			//circle = makeCircle(-50,frameLength_y_temperature*i+20);
			text_value = makeBlueText((100-i*20).toString(),-55,frameLength_y_temperature*i+13);
			main_layer.add(text_value);
		}
		//draw x (hour/day)
		
		if(index_tab == 0)
		{
			text_value = makeText('時間',750,420+7);
			line = makeGrayLineStrong([ -100, 420, 721, 420 ]);
			main_layer.add(text_value,line);
			
			frameLength_x_hour = 30;
			for(i=0;i<=24;i++)
			{
				//circle = makeCircle(frameLength_x_hour*i,420);
				
				if((24-i)%10==0 || i == 0)
				{
					gray_line = makeGrayLineStrong([frameLength_x_hour*i,420,frameLength_x_hour*i,20]);
					text_value = makeText(((24-i)*-1).toString(),frameLength_x_hour*i+4,420+7);
					main_layer.add(text_value,gray_line);	
				}
				else
				{
					gray_line = makeGrayLine([frameLength_x_hour*i,420,frameLength_x_hour*i,20]);
					main_layer.add(gray_line);
				}
				
			}
			
			drawingChart(array_c,array_percent,frameLength_x_hour);//call draw chart
		}
		//draw x (day/month)
		else
		{
			text_value = makeText('日',750,420+7);
			line = makeGrayLineStrong([ -100, 420, 721, 420 ]);
			triangle = makeTriangle(800,420,90);
			main_layer.add(text_value,line);
			
			frameLength_x_day = 24;
			for(i=0;i<31;i++)
			{
				//circle = makeCircle(frameLength_x_day*i,420);
				if(i==0 || (30-i)%10==0)
				{
					gray_line = makeGrayLineStrong([frameLength_x_day*i,420,frameLength_x_day*i,20]);
					text_value = makeText(((30-i)*-1).toString(),frameLength_x_day*i+4,420+7);
					main_layer.add(text_value,gray_line);
				}
				else
				{
					gray_line = makeGrayLine([frameLength_x_day*i,420,frameLength_x_day*i,20]);
					main_layer.add(gray_line);
				}
			}
			
			drawingChart(array_c,array_percent,frameLength_x_day);//call draw chart
		}
		
		canvas.add(main_layer);
		canvas.sendBackwards(main_layer);
		
	}//end draw frame
	function drawingChart(array_1,array_2, line_length)//draw chart
	{
		var main_chart = new fabric.Group([], {	  left: 170,	top: 70	, selectable: false});

		for(i=0;i<array_1.length-1;i++)
		{
			
			r_x1= 320-((array_1[array_1.length-1-i])*8);	
			r_x2= 320-((array_1[array_1.length-2-i])*8);	
				
			b_x1= 400-((array_2[array_2.length-1-i])*4);	
			b_x2= 400-((array_2[array_2.length-2-i])*4);
			
			line_red  = makeRedLine([line_length*i,r_x1,line_length*(i+1),r_x2   ]);
			line_blue = makeBlueLine([line_length*i,b_x1,line_length*(i+1),b_x2   ]);

			main_chart.add(line_red,line_blue);
		}
		canvas.add(main_chart);
	}//end draw chart
	
	// event
	$(".ul_tab li").click(function(e){
		if($(this).index() != index_tab)
		{
			canvas.clear();
			index_tab = $(this).index();
			$('.ul_tab li a').removeClass("act");
			$('.ul_tab li a').eq(index_tab).addClass("act");
			if(index_tab == 0)
			{
				text_value = makeTitle('温度・湿度２４時間データ',550,30);
				canvas.add(text_value);
				drawingFramesChart(array_hour_c,array_hour_percent);	
			}
			
			else
			{
				text_value = makeTitle('温度・湿度３０日データ',550,30);
				canvas.add(text_value);
				
				drawingFramesChart(array_day_c,array_day_percent);	
			}
			
		}
	});
});


